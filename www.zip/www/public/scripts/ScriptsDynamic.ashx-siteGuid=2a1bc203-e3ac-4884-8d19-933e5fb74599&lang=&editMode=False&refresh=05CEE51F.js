
function jsHelper() { 
                            this.CurrentSiteGuid = '2a1bc203-e3ac-4884-8d19-933e5fb74599'; 
                            this.CurrentLanguageShortcut = ''; 
                            this.SiteUrl = 'http://hofgutstorzeln.de/';                                                       
                        }
                        var GlobalJsHelper = new jsHelper();
                        
